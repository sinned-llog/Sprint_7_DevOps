import os
import requests

# definition of the API address
api_address = os.environ.get('API_ADDRESS', 'api')
api_port = os.environ.get('API_PORT', '8000')

# reqest
def authentication_test(api_address, api_port, username, password):
    url=f'http://{api_address}:{api_port}/permissions'
    r = requests.get(
        url=url,
        params= {
            'username': username,
            'password': password
        }
    )
    output = '''

    =============================
    Authentication test
    =============================
    request done at "/permissions"
    | username="{username}"
    | password="{password}"
        expected result = 200
    actual result = {status_code}
    ==>  {test_status}
    '''
    # query status
    status_code = r.status_code

    # display the results
    if status_code == 200:
        test_status = 'SUCCESS'
    else:
        test_status = 'FAILURE'

    print(output.format(
        username=username, 
        password=password, 
        status_code=status_code, 
        test_status=test_status
        ))
    
    formatted_output = output.format(
        username=username, 
        password=password, 
        status_code=status_code, 
        test_status=test_status
        )
    return formatted_output

users = [
    {'username': 'alice', 'password': 'wonderland'},
    {'username': 'bob', 'password': 'builder'},
    {'username': 'clementine', 'password': 'mandarin'},
    ]

for user in users:
    result = authentication_test(api_address, api_port, user['username'], user['password'])
    # printing in a file
    if os.environ.get('LOG') == '1':
        os.makedirs('/logs', exist_ok=True)
        with open('/logs/authentication_test.txt', 'a') as file:
            file.write(result)


